# JDM Kivy

## This is my own kivy library, just like a snippet.